"""Train, compare and evaluate fraud models, then compute the dollar business case.

Usage:
    python -m src.train --data data/PS_20174392719_1491204439457_log.csv \
                        --cost-false-alarm 5

Outputs (written to reports/):
    results.json                  metrics + dollar impact per model
    figures/pr_curves.png         precision-recall curves
    figures/net_value_<model>.png net value vs. decision threshold
    figures/shap_summary.png      (optional) SHAP summary for the best model
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_curve
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_sample_weight

from src.evaluate import (best_threshold, net_value_curve, pr_auc,
                          recall_at_precision, value_at_threshold)
from src.features import (FEATURE_COLUMNS, TARGET, add_features, load_data,
                          time_split)

SEED = 42


def build_models() -> dict:
    """Baseline first, then progressively stronger models."""
    return {
        "logistic_regression (baseline)": make_pipeline(
            StandardScaler(),
            LogisticRegression(max_iter=1000, class_weight="balanced", random_state=SEED),
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=200, min_samples_leaf=2, class_weight="balanced_subsample",
            n_jobs=-1, random_state=SEED,
        ),
        "hist_gradient_boosting": HistGradientBoostingClassifier(
            max_depth=6, learning_rate=0.1, max_iter=200, random_state=SEED,
        ),
    }


def fit_model(name: str, model, X, y):
    if name.startswith("hist_gradient_boosting"):
        model.fit(X, y, sample_weight=compute_sample_weight("balanced", y))
    else:
        model.fit(X, y)
    return model


def main(args) -> None:
    out_dir = Path(args.out)
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)

    df = add_features(load_data(args.data))
    train, val, test = time_split(df)
    print(f"Rows  train={len(train):,}  val={len(val):,}  test={len(test):,}")
    print(f"Fraud rate  train={train[TARGET].mean():.4%}  test={test[TARGET].mean():.4%}")

    X_tr, y_tr = train[FEATURE_COLUMNS], train[TARGET]
    X_va, y_va = val[FEATURE_COLUMNS], val[TARGET]
    X_te, y_te = test[FEATURE_COLUMNS], test[TARGET]

    results, fitted = {}, {}
    plt.figure(figsize=(7, 5))
    for name, model in build_models().items():
        print(f"Training {name} ...")
        model = fit_model(name, model, X_tr, y_tr)
        fitted[name] = model

        # Threshold is chosen on VALIDATION data, then frozen for the test set.
        val_scores = model.predict_proba(X_va)[:, 1]
        thr, _ = best_threshold(y_va, val_scores, val["amount"], args.cost_false_alarm)

        test_scores = model.predict_proba(X_te)[:, 1]
        results[name] = {
            "pr_auc_test": pr_auc(y_te, test_scores),
            "recall_at_90pct_precision": recall_at_precision(y_te, test_scores, 0.9),
            "business_case_test": value_at_threshold(
                y_te, test_scores, test["amount"], thr, args.cost_false_alarm),
            "total_fraud_amount_in_test": float(test.loc[y_te == 1, "amount"].sum()),
        }

        p, r, _ = precision_recall_curve(y_te, test_scores)
        plt.plot(r, p, label=f"{name} (AP={results[name]['pr_auc_test']:.3f})")

        ths, vals = net_value_curve(y_te, test_scores, test["amount"], args.cost_false_alarm)
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.plot(ths, vals)
        ax.axvline(thr, ls="--", c="gray", label="threshold chosen on validation")
        ax.set(xlabel="Decision threshold", ylabel="Net value vs. no model",
               title=f"Net value: {name}")
        ax.legend()
        fig.tight_layout()
        safe = name.split(" ")[0]
        fig.savefig(fig_dir / f"net_value_{safe}.png", dpi=150)
        plt.close(fig)

    plt.xlabel("Recall"); plt.ylabel("Precision"); plt.title("Precision-recall curves (test)")
    plt.legend(); plt.tight_layout()
    plt.savefig(fig_dir / "pr_curves.png", dpi=150)
    plt.close()

    (out_dir / "results.json").write_text(json.dumps(results, indent=2))
    print(json.dumps({k: v["business_case_test"]["net_value"] for k, v in results.items()},
                     indent=2))

    if args.shap:
        try:
            import shap
            best = max(results, key=lambda k: results[k]["business_case_test"]["net_value"])
            sample = X_te.sample(min(2000, len(X_te)), random_state=SEED)
            explainer = shap.Explainer(fitted[best].predict_proba, sample)
            sv = explainer(sample.iloc[:500])
            shap.summary_plot(sv[..., 1], sample.iloc[:500], show=False)
            plt.tight_layout()
            plt.savefig(fig_dir / "shap_summary.png", dpi=150)
            plt.close()
        except ImportError:
            print("Install `shap` to produce the SHAP summary plot.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Path to the PaySim CSV")
    ap.add_argument("--out", default="reports", help="Output directory")
    ap.add_argument("--cost-false-alarm", type=float, default=5.0,
                    help="Assumed cost (currency) of wrongly flagging one legitimate transaction")
    ap.add_argument("--shap", action="store_true", help="Also produce a SHAP summary plot")
    main(ap.parse_args())
