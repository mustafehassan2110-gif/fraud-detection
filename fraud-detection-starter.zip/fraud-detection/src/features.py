"""Data loading and feature engineering for the PaySim mobile-money dataset.

Expected raw columns:
    step, type, amount, nameOrig, oldbalanceOrg, newbalanceOrig,
    nameDest, oldbalanceDest, newbalanceDest, isFraud, isFlaggedFraud

Design decisions (explain these in your README):
  * `isFlaggedFraud` is dropped: it is produced by the provider's own rule
    and would leak information about the label.
  * Fraud only occurs in TRANSFER and CASH_OUT, so we keep just those types.
  * Account names are dropped (near-unique IDs, no generalisable signal).
  * Splitting is done by time (`step` = 1 hour), never randomly.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

FRAUD_TYPES = ["TRANSFER", "CASH_OUT"]
TARGET = "isFraud"


def load_data(path: str) -> pd.DataFrame:
    """Read the raw CSV and keep only the transaction types where fraud occurs."""
    df = pd.read_csv(path)
    return df[df["type"].isin(FRAUD_TYPES)].reset_index(drop=True)


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return a model-ready copy of `df` with engineered features."""
    out = df.copy()

    # Balance bookkeeping errors: for a clean transaction these are ~0.
    out["error_balance_orig"] = out["newbalanceOrig"] + out["amount"] - out["oldbalanceOrg"]
    out["error_balance_dest"] = out["oldbalanceDest"] + out["amount"] - out["newbalanceDest"]

    # Classic fraud pattern: the origin account is drained completely.
    out["orig_emptied"] = (
        (out["oldbalanceOrg"] > 0) & (out["newbalanceOrig"] == 0)
    ).astype(int)
    out["dest_was_empty"] = (out["oldbalanceDest"] == 0).astype(int)

    # Time features (step = 1 hour of the simulation).
    out["hour_of_day"] = out["step"] % 24

    # Amounts are heavily right-skewed.
    out["log_amount"] = np.log1p(out["amount"])

    out["is_transfer"] = (out["type"] == "TRANSFER").astype(int)
    return out


FEATURE_COLUMNS = [
    "amount", "log_amount", "oldbalanceOrg", "newbalanceOrig",
    "oldbalanceDest", "newbalanceDest", "error_balance_orig",
    "error_balance_dest", "orig_emptied", "dest_was_empty",
    "hour_of_day", "is_transfer",
]


def time_split(df: pd.DataFrame, train_frac: float = 0.6, val_frac: float = 0.2):
    """Chronological train / validation / test split on `step`.

    Training on the past and testing on the future mimics real deployment and
    avoids the leakage a random split would create.
    """
    t_train = df["step"].quantile(train_frac)
    t_val = df["step"].quantile(train_frac + val_frac)
    train = df[df["step"] <= t_train]
    val = df[(df["step"] > t_train) & (df["step"] <= t_val)]
    test = df[df["step"] > t_val]
    return train, val, test
