"""Generate a small PaySim-like synthetic CSV to smoke-test the pipeline.

This is NOT the real dataset. Use it only to check that the code runs;
download the real PaySim file from Kaggle for your actual results.

    python -m src.make_sample_data --out data/sample.csv
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd


def make_sample(n: int = 60_000, fraud_rate: float = 0.01, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    step = rng.integers(1, 744, n)
    type_ = rng.choice(["TRANSFER", "CASH_OUT", "PAYMENT", "CASH_IN", "DEBIT"], n,
                       p=[0.2, 0.35, 0.3, 0.1, 0.05])
    is_fraud = ((rng.random(n) < fraud_rate / 0.55) &
                np.isin(type_, ["TRANSFER", "CASH_OUT"])).astype(int)

    old_org = rng.lognormal(9, 1.5, n)
    amount = np.where(is_fraud == 1, old_org * rng.uniform(0.9, 1.0, n),
                      rng.lognormal(8, 1.3, n))
    new_org = np.where(is_fraud == 1, 0.0, np.maximum(old_org - amount, 0))
    old_dest = np.where(rng.random(n) < 0.4, 0.0, rng.lognormal(9, 1.5, n))
    new_dest = np.where(is_fraud == 1, old_dest, old_dest + amount)

    return pd.DataFrame({
        "step": step, "type": type_, "amount": amount.round(2),
        "nameOrig": [f"C{i}" for i in range(n)],
        "oldbalanceOrg": old_org.round(2), "newbalanceOrig": new_org.round(2),
        "nameDest": [f"M{i}" for i in range(n)],
        "oldbalanceDest": old_dest.round(2), "newbalanceDest": new_dest.round(2),
        "isFraud": is_fraud, "isFlaggedFraud": 0,
    })


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="data/sample.csv")
    p.add_argument("--n", type=int, default=60_000)
    args = p.parse_args()
    make_sample(args.n).to_csv(args.out, index=False)
    print(f"Wrote {args.n} synthetic rows to {args.out}")
