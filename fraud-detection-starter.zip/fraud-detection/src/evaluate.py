"""Evaluation helpers: ML metrics plus the dollar-value business case.

Net value of a model versus having no model, at a given threshold:

    net_value = (amount of fraud caught)
                - cost_per_false_alarm * (number of false alarms)

A "no model" system catches nothing, so its value is 0 by definition.
Set `cost_per_false_alarm` to a defensible assumption (support call, customer
friction, blocked-sale loss) and state it in the README.
"""
from __future__ import annotations

import numpy as np
from sklearn.metrics import average_precision_score, precision_recall_curve


def pr_auc(y_true, scores) -> float:
    """Area under the precision-recall curve (right metric for rare fraud)."""
    return float(average_precision_score(y_true, scores))


def recall_at_precision(y_true, scores, min_precision: float = 0.9) -> float:
    """Best recall achievable while keeping precision >= `min_precision`."""
    precision, recall, _ = precision_recall_curve(y_true, scores)
    ok = precision >= min_precision
    return float(recall[ok].max()) if ok.any() else 0.0


def net_value_curve(y_true, scores, amounts, cost_per_false_alarm: float = 5.0,
                    n_thresholds: int = 200):
    """Net value (in currency units) for a grid of thresholds."""
    y_true = np.asarray(y_true)
    scores = np.asarray(scores)
    amounts = np.asarray(amounts)
    thresholds = np.unique(np.quantile(scores, np.linspace(0, 1, n_thresholds)))
    values = []
    for t in thresholds:
        flagged = scores >= t
        caught = amounts[flagged & (y_true == 1)].sum()
        false_alarms = int((flagged & (y_true == 0)).sum())
        values.append(caught - cost_per_false_alarm * false_alarms)
    return thresholds, np.array(values)


def best_threshold(y_true, scores, amounts, cost_per_false_alarm: float = 5.0):
    """Threshold that maximises net value, and that value."""
    thresholds, values = net_value_curve(y_true, scores, amounts, cost_per_false_alarm)
    i = int(values.argmax())
    return float(thresholds[i]), float(values[i])


def value_at_threshold(y_true, scores, amounts, threshold: float,
                       cost_per_false_alarm: float = 5.0) -> dict:
    """Confusion counts and dollar impact at a fixed threshold."""
    y_true = np.asarray(y_true)
    flagged = np.asarray(scores) >= threshold
    amounts = np.asarray(amounts)
    tp = int((flagged & (y_true == 1)).sum())
    fp = int((flagged & (y_true == 0)).sum())
    fn = int((~flagged & (y_true == 1)).sum())
    caught = float(amounts[flagged & (y_true == 1)].sum())
    missed = float(amounts[~flagged & (y_true == 1)].sum())
    return {
        "threshold": float(threshold),
        "true_positives": tp, "false_positives": fp, "false_negatives": fn,
        "fraud_amount_caught": caught, "fraud_amount_missed": missed,
        "false_alarm_cost": cost_per_false_alarm * fp,
        "net_value": caught - cost_per_false_alarm * fp,
    }
